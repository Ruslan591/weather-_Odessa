D=/opt/trading-bot; L=$D/live; P=$D/positions; T=/tmp/lb
chk() { [ "$(md5sum < $1 | cut -d' ' -f1)" = "$2" ] || { echo "DIVERGED $1"; exit 1; }; }
chk $L/live_web.py f16a61ffd04f3587cb4381edeef1274d
chk $L/index.html 798b50a44cc8efa4b57a099856789834
chk $P/shadow_ledger.py 91cced4de480e93b56d8e83abc5a8bdc
python3 -m py_compile $T/live_web.py $T/shadow_ledger.py || { echo COMPILE_FAIL; exit 1; }
mkdir -p $T/j; LEDGER_JOURNAL_DIR=$T/j python3 $T/test_compute.py || { echo TEST_FAIL; exit 1; }
B=$D/bak_livebal_$(date +%Y%m%d_%H%M%S); mkdir -p $B; cp -p $L/live_web.py $L/index.html $P/shadow_ledger.py $B/ || exit 1
cat $T/live_web.py > $L/live_web.py; cat $T/index.html > $L/index.html; cat $T/shadow_ledger.py > $P/shadow_ledger.py
python3 $T/merge_journal.py && chown tbot:tbot $L/data/shadow_bal_trades.json
[ -f $L/shadow_bal_trades.json ] && mv $L/shadow_bal_trades.json $B/root_shadow_bal_trades.json
systemctl restart live-web; sleep 8
if systemctl is-active live-web >/dev/null; then echo LIVE_ACTIVE; else echo LIVE_FAILED_ROLLBACK; cat $B/live_web.py > $L/live_web.py; cat $B/index.html > $L/index.html; cat $B/shadow_ledger.py > $P/shadow_ledger.py; systemctl restart live-web; fi
journalctl -u live-web --since "-20s" --no-pager 2>&1 | tail -6
echo BACKUP $B
