# -*- coding: utf-8 -*-
"""live_web: живая страница бота по WebSocket. ТОЛЬКО ЧТЕНИЕ: ничего не пишет, торговых команд не принимает.
Источники: POS_DIR (orders.json, tg_watch.json, decisions.jsonl, tg_*.json), acct-api (GET /api/claude), цены Binance (публичный поток, ретрансляция).
Вход: Telegram Mini App (подпись initData по токену бота и TG_USER_ID) или секретная ссылка (token.txt). Не больше 3 подключений.
Настройки: порт LIVE_PORT (18110), Caddy проксирует /live* на него. docs/topics/live_web.md"""
import asyncio, collections, hashlib, hmac, json, os, re, signal, time, urllib.parse
from aiohttp import web, ClientSession, ClientTimeout, WSMsgType

POS = os.environ.get("POS_DIR", "/opt/trading-bot/positions_regr")
try:
    import sys as _sys; _sys.path.insert(0, "/opt/trading-bot/positions"); import shadow_ledger as SL
except Exception as _e: SL = None
try:
    import exit_cfg as EC
except Exception: EC = None
PORT = int(os.environ.get("LIVE_PORT", "18110"))
CTL_PORT = int(os.environ.get("LIVE_CTL_PORT", "18111"))   # порт управления: только localhost, на VPS не проброшен наружу, доступен через туннель SSH из Termux
AUDIT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ctl_audit.log")
HERE = os.path.dirname(os.path.abspath(__file__))
SNAP = "http://127.0.0.1:%s/api/claude" % os.environ.get("ACCT_PORT", "18102")
BWS = "wss://data-stream.binance.vision/stream"
REST = "https://data-api.binance.vision/api/v3/ticker/price"
KL = "https://data-api.binance.vision/api/v3/klines"
IVS = {"1s": 1000, "1m": 60000, "5m": 300000, "15m": 900000, "1h": 3600000, "4h": 14400000, "1d": 86400000}
MAXC = 3


def _env():
    d = {}
    try:
        for l in open(os.environ.get("TG_ENV", "/opt/trading-bot/tg.env"), encoding="utf-8"):
            l = l.strip()
            if l and not l.startswith("#") and "=" in l:
                k, v = l.split("=", 1); d[k.strip()] = v.strip().strip('"').strip("'")
    except Exception: pass
    return d


ENV = _env(); BOT = ENV.get("TG_TOKEN", ""); UID = str(ENV.get("TG_USER_ID", ""))
try: TOK = open(os.path.join(HERE, "token.txt"), encoding="utf-8").read().strip()
except Exception: TOK = ""

PX = {}; BTCK = {}; DIRTY = set(); CL = set(); EVT = collections.deque(maxlen=120); NEW = []
ST = {"state": None, "sig": None, "syms": set(), "arch": [], "asig": None, "extra": {}, "force": False}; CHANS = {}; LASTQ = {}; FAILS = {}; CACHE = {}; OSEEN = {}; DEC = {"pos": None, "buf": b""}; BASE = {"orders": False}


def log(m): print("%s %s" % (time.strftime("%m-%d %H:%M:%S", time.gmtime()), m), flush=True)


# ---------- вход ----------
def check_init(init):
    try:
        q = dict(urllib.parse.parse_qsl(init, keep_blank_values=True))
        h = q.pop("hash", "")
        dcs = "\n".join("%s=%s" % (k, q[k]) for k in sorted(q))
        key = hmac.new(b"WebAppData", BOT.encode(), hashlib.sha256).digest()
        if not BOT or not hmac.compare_digest(hmac.new(key, dcs.encode(), hashlib.sha256).hexdigest(), h): return False
        if time.time() - int(q.get("auth_date", "0")) > 86400: return False
        return bool(UID) and str(json.loads(q.get("user", "{}")).get("id")) == UID
    except Exception: return False


def check_tok(t): return bool(TOK) and hmac.compare_digest(str(t), TOK)


def n_fails(ip):
    now = time.time(); FAILS[ip] = [t for t in FAILS.get(ip, []) if now - t < 600]; return len(FAILS[ip])


# ---------- данные ----------
def jl(name):
    p = os.path.join(POS, name)
    try: s = os.stat(p); ver = (s.st_mtime_ns, s.st_size)
    except OSError: return None
    c = CACHE.get(name)
    if c and c[0] == ver: return c[1]
    try: d = json.load(open(p, encoding="utf-8"))
    except Exception: return c[1] if c else None
    if name == "orders.json" and isinstance(d, list):      # файл на МБ: каналы запоминаем по всем ордерам (для графика сделки), остальное только свежие
        for o in d:
            if o.get("chan") and o.get("id") is not None: CHANS[o["id"]] = o["chan"]
        d = d[-400:]
    CACHE[name] = (ver, d); return d


def ev(t, k, x, s="", new=True):
    e = {"t": int(t), "k": k, "x": x, "s": s}; EVT.append(e)
    if new: NEW.append(e)


def fmt_dec(d):
    k = str(d.get("kind") or ""); a = str(d.get("action") or "")
    bits = [("%s/%s" % (k, a)) if a else k, str(d.get("sym") or ""), str(d.get("side") or "")]
    for key in ("reason_text", "reason", "setup", "entry", "price"):
        v = d.get(key)
        if v not in (None, ""): bits.append("%s=%s" % (key, str(v)[:60]))
    return " ".join(b for b in bits if b)[:200]


def tail_decisions():
    p = os.path.join(POS, "decisions.jsonl")
    try: size = os.path.getsize(p)
    except OSError: return
    first = DEC["pos"] is None
    if first: start = max(0, size - 80000)
    else:
        start = DEC["pos"]
        if size < start: start = 0; DEC["buf"] = b""
        if size == start: return
    with open(p, "rb") as f:
        f.seek(start); data = f.read(min(size - start, 400000))
    DEC["pos"] = start + len(data)
    lines = (DEC["buf"] + data).split(b"\n"); DEC["buf"] = lines.pop()
    if first and start > 0 and lines: lines.pop(0)
    for l in lines[-200:]:
        try: d = json.loads(l)
        except Exception: continue
        ev(d.get("t") or time.time() * 1000, "dec", fmt_dec(d), str(d.get("sym") or ""), new=not first)


OPEN_F = ("id", "sym", "side", "entry", "stop", "stop0", "tp", "R", "stake", "lev", "t_in", "armed", "be_px", "lock_px", "order_id", "stop_manual", "tp_manual", "manual_trail", "rem")
CLOSED_F = ("id", "sym", "side", "entry", "exit", "stop0", "stop", "tp", "t_in", "t_out", "net_pct", "r_mult", "pnl_usd", "reason", "order_id", "stake", "be_px", "lock_px")
ORD_F = ("id", "sym", "side", "price", "stop", "tp", "atr", "line_px", "live1m", "live1m_tries", "rule", "approved_t", "placed_t", "setup")


SH_V1 = ("id", "sym", "side", "kind", "tf", "entry", "stop", "tp", "t_in", "t_out", "exit", "reason", "net_pct", "r_mult", "mfe", "mae", "status", "rr")


def _evc(ev):
    """События сопровождения тени для графика панели (компактно, не больше 40 последних)."""
    out = []
    for e in (ev or [])[-40:]:
        if isinstance(e, dict): out.append({k: e[k] for k in ("t", "k", "old", "new", "px", "frac", "reason", "stop_from", "stop_to", "n") if k in e})
    return out


def build_shadow():
    """SHADOW_V2. Тени (пропущенные сигналы «заходить»): ждёт свечу 1m (gate), идёт (open), закрыта (closed), не вошла по фильтру входа (filtered, с итогом «без фильтра» cf_r). Файл shadow.json пишет tg_bot, здесь только чтение."""
    d = jl("shadow.json"); its = d.get("items") if isinstance(d, dict) else None; out = []
    _bc = jl("shadow_bal.json"); _bc = _bc if isinstance(_bc, dict) else {}; _stf = set(_bc.get("skip_tf", ["5m"])); _srg = set(_bc.get("skip_regime", ["flat"]))
    for i in (its or []):
        st = i.get("status")
        if st not in ("gate", "open", "closed", "filtered"): continue
        if "o" not in i and "p" not in i:      # записи первой версии
            r = {k: i.get(k) for k in SH_V1}; r["ch"] = i.get("ch"); out.append(r); continue
        p = i.get("p") or {}; cf = i.get("cf") or {}; o = i.get("o") or {}; pl = i.get("plan") or {}; src = p or cf
        cl = (p if st in ("open", "closed") else cf) or {}; done = cl.get("status") == "closed"
        ch = i.get("chan") or {}
        r = {"id": i["id"], "sym": i["sym"], "side": i["side"], "kind": i.get("kind"), "tf": i.get("tf"), "status": st, "t_sig": i.get("t0"),
             "entry": src.get("entry") or o.get("price") or pl.get("entry"), "stop": src.get("stop0") or o.get("stop") or pl.get("stop"), "tp": src.get("tp") or o.get("tp") or pl.get("tp"),
             "t_in": src.get("t_in") or i.get("t0"), "t_out": cl.get("t_out") if done else None, "exit": cl.get("exit") if done else None, "reason": cl.get("reason") if done else None,
             "net_pct": cl.get("net_pct") if done else None, "r_mult": (cl.get("r_mult") if done else None) if st != "filtered" else None, "cf_r": cf.get("r_mult") if (st == "filtered" and done) else None,
             "mfe": i.get("mfe_r"), "mae": i.get("mae_r"), "why": i.get("why"), "tries": o.get("live1m_tries"), "rr": pl.get("rr"),
             "ch": {k: ch[k] for k in ("upper", "lower", "type") if k in ch} or None, "var": i.get("var") or "A", "reg": i.get("reg"), "sn": i.get("sn") or ((i.get("ref") or i["id"]) if i.get("var") == "B" else i["id"]), "ev": _evc(i.get("ev"))}
        if EC and src:      # цель на графике = цель движка (exit_cfg), план остаётся в tp_plan
            try:
                pp = dict(src); pp.setdefault("side", i.get("side")); pp.setdefault("entry", r["entry"])
                tpe = EC.levels(pp).get("tp")
                if tpe: r["tp_plan"] = r["tp"]; r["tp"] = tpe
            except Exception: pass
        if (i.get("tf") in _stf) or ((i.get("rg") or {}).get("regime") in _srg): r["nb"] = 1   # не идёт в баланс (фильтр)
        out.append(r)
    out.sort(key=lambda x: (x["status"] in ("gate", "open"), x.get("t_out") or x.get("t_sig") or x.get("t_in") or 0), reverse=True)
    return out[:150]


def derive(snap):
    orders = jl("orders.json") or []; W = jl("tg_watch.json") or {}
    b1 = jl("tg_btc1m_last.json"); reg = jl("tg_regime.json"); sl = jl("tg_slots.json"); mode = jl("tg_mode.json"); lc = jl("tg_live1m.json") or {}
    now = int(time.time() * 1000)
    pend = [dict({k: o.get(k) for k in ORD_F}, ch=o.get("chan")) for o in orders if o.get("status") == "pending"][-20:]
    for o in orders[-80:]:
        if not str(o.get("rule", "")).startswith("tg_"): continue
        l1 = o.get("live1m") or {}; sig = (o.get("status"), o.get("live1m_tries"), l1.get("ok")); old = OSEEN.get(o["id"]); OSEEN[o["id"]] = sig
        if old is None or old == sig or not BASE["orders"]: continue
        nm = "#%s %s %s" % (o["id"], o.get("sym"), str(o.get("side", "")).upper())
        if old[0] != sig[0]:
            st = o.get("status")
            ev(now, "ord", "Ордер %s: %s%s" % (nm, {"cancelled": "отменён", "expired": "истёк", "filled": "исполнен"}.get(st, str(st)), (" - %s" % o.get("reason")) if o.get("reason") else ""), o.get("sym"))
        elif l1.get("ok") == 0:
            bo, bc = l1.get("o"), l1.get("c")
            ev(now, "l1m", "⏳ %s: свеча %s 1m не по ходу (%+.3f%%), попытка %s" % (nm, "BTC" if l1.get("src", "btc") == "btc" else o.get("sym"), (bc / bo - 1) * 100 if bo else 0, o.get("live1m_tries")), o.get("sym"))
        elif l1.get("ok") == 1:
            ev(now, "l1m", "✅ %s: свеча %s 1m по ходу, вход открыт (попытка %s)" % (nm, "BTC" if l1.get("src", "btc") == "btc" else o.get("sym"), o.get("live1m_tries")), o.get("sym"))
    BASE["orders"] = True
    watch = []
    for w in W.get("items", []):
        if w.get("status") in ("alert", "watching"):
            L = w.get("last") or {}; line = L.get("Rn") if w.get("line") == "upper" else L.get("Sn")
            watch.append({"id": w["id"], "sym": w["sym"], "side": w.get("side"), "line": w.get("line"), "lp": line if line is not None else w.get("line_px"),
                          "atr": L.get("atr") or w.get("atr"), "state": w.get("state"), "nb": w.get("n_beyond"), "ct": w.get("ctype"), "st": w.get("status"), "upd": w.get("updates"), "tf": w.get("t_follow") or w.get("created"), "ch": w.get("chan"), "keep": bool(w.get("keep"))})
    watch = watch[-20:]
    s = snap if isinstance(snap, dict) else {}
    st = {"t": "state", "acc": s.get("account"), "open": [dict({k: p.get(k) for k in OPEN_F}, ch=CHANS.get(p.get("order_id"))) for p in (s.get("open") or [])], "pend": pend, "watch": watch,
          "b1": b1, "reg": reg, "slots": sl, "mode": mode, "mx": float(lc.get("max_dist_atr", 0.9)) if lc.get("enabled", True) else None}
    syms = {"BTCUSDT"} | {p["sym"] for p in st["open"]} | {o["sym"] + "USDT" for o in pend} | {w["sym"] + "USDT" for w in watch} | {x["sym"] + "USDT" for x in [y for y in build_shadow() if y["status"] == "open"][:6]}
    return st, set(list(syms)[:30])


def build_arch(snap):
    c = (snap or {}).get("closed") if isinstance(snap, dict) else None
    out = [{k: p.get(k) for k in CLOSED_F} for p in (c or []) if p.get("t_out")]
    out.sort(key=lambda x: x["t_out"], reverse=True); return out


# ---------- рассылка ----------
async def bcast(msg):
    if not CL: return
    s = json.dumps(msg, ensure_ascii=False, separators=(",", ":"))
    for ws in list(CL):
        try: await asyncio.wait_for(ws.send_str(s), 2)
        except Exception:
            CL.discard(ws); asyncio.ensure_future(ws.close())


async def state_loop(app):
    sess = app["sess"]; loop = asyncio.get_running_loop(); nxt = 0; snap = None
    while True:
        try:
            if time.time() >= nxt or ST["force"]:
                ST["force"] = False; nxt = time.time() + 3
                try:
                    async with sess.get(SNAP) as r: snap = await r.json()
                except Exception as e: log("snap: %s" % e)
            await loop.run_in_executor(None, tail_decisions)
            st, syms = await loop.run_in_executor(None, derive, snap)
            if isinstance(snap, dict):
                arch = build_arch(snap); asig = (len(arch), arch[0]["id"] if arch else None, arch[0]["t_out"] if arch else None)
                if asig != ST["asig"]: ST["asig"] = asig; ST["arch"] = arch; await bcast({"t": "arch", "a": arch})
            try:
                shl = build_shadow(); ssig = json.dumps(shl, sort_keys=True, ensure_ascii=False, default=str)
                if ssig != ST.get("ssig"): ST["ssig"] = ssig; ST["sh"] = shl; await bcast({"t": "sh", "a": shl})
            except Exception as e: log("shadow: %s" % e)
            try:
                bl = await loop.run_in_executor(None, SL.compute, POS) if SL else None
                bsig = json.dumps(bl, sort_keys=True, ensure_ascii=False, default=str)
                if bsig != ST.get("bsig"): ST["bsig"] = bsig; ST["bal"] = bl; await bcast({"t": "bal", "a": bl})
            except Exception as e: log("bal: %s" % e)
            try:    # LIVE_BAL: символы открытых сделок баланса и строк теней без подписки: цены раз в 5 с по REST
                _ls = set()
                for _L in ((ST.get("bal") or {}).get("lines") or []):
                    for _o in list(_L.get("open_list") or []) + list((_L.get("full") or {}).get("open_list") or []):
                        if _o.get("sym"): _ls.add(_o["sym"])
                for _i in (ST.get("sh") or []):
                    if _i.get("status") in ("gate", "open") or (_i.get("status") == "filtered" and _i.get("cf_r") is None): _ls.add(_i["sym"])
                _lx = sorted(x for x in _ls if x not in syms)[:60]
                if _lx and time.time() - ST.get("lpx_t", 0) > 5:
                    ST["lpx_t"] = time.time()
                    async with sess.get(REST, params={"symbols": json.dumps(_lx, separators=(",", ":"))}) as r:
                        for x in await r.json():
                            if isinstance(x, dict) and "price" in x: PX[x["symbol"]] = float(x["price"]); DIRTY.add(x["symbol"])
            except Exception as e: log("livepx: %s" % e)
            ST["syms"] = syms; sig = json.dumps(st, sort_keys=True, ensure_ascii=False, default=str)
            if sig != ST["sig"]: ST["sig"] = sig; ST["state"] = st; await bcast(dict(st, srv=int(time.time() * 1000)))
            while NEW: await bcast({"t": "evt", "e": NEW.pop(0)})
            miss = [s for s in syms if s not in PX]
            if miss:
                try:
                    async with sess.get(REST, params={"symbols": json.dumps(miss, separators=(",", ":"))}) as r:
                        for x in await r.json():
                            if isinstance(x, dict) and "price" in x: PX[x["symbol"]] = float(x["price"]); DIRTY.add(x["symbol"])
                except Exception: pass
        except Exception as e: log("state_loop: %s" % e)
        await asyncio.sleep(1)


async def px_loop(app):
    last = None
    while True:
        await asyncio.sleep(0.2)
        if not CL: DIRTY.clear(); continue
        if DIRTY or BTCK.get("c") != last:
            p = {s: PX[s] for s in list(DIRTY) if s in PX}; DIRTY.clear(); last = BTCK.get("c")
            await bcast({"t": "px", "p": p, "k": BTCK, "srv": int(time.time() * 1000)})


async def binance_loop(app):
    sess = app["sess"]; back = 1
    while True:
        try:
            async with sess.ws_connect(BWS, heartbeat=20, receive_timeout=60) as ws:
                back = 1; subs = set(); last = 0
                while True:
                    if time.time() - last > 2:
                        last = time.time(); ex = {s for s, t in ST["extra"].items() if t > time.time()}; want = {"btcusdt@kline_1m"} | {s.lower() + "@aggTrade" for s in (ST["syms"] | ex)}
                        add = sorted(want - subs); rem = sorted(subs - want)
                        if rem: await ws.send_json({"method": "UNSUBSCRIBE", "params": rem, "id": 1})
                        if add: await ws.send_json({"method": "SUBSCRIBE", "params": add, "id": 2})
                        subs = want
                    try: m = await ws.receive(timeout=2)
                    except asyncio.TimeoutError: continue
                    if m.type == WSMsgType.TEXT:
                        d = (json.loads(m.data) or {}).get("data") or {}
                        if d.get("e") == "aggTrade": PX[d["s"]] = float(d["p"]); DIRTY.add(d["s"])
                        elif d.get("e") == "kline":
                            k = d["k"]; BTCK.update(o=float(k["o"]), c=float(k["c"]), h=float(k["h"]), l=float(k["l"]), t=k["t"]); PX["BTCUSDT"] = float(k["c"]); DIRTY.add("BTCUSDT")
                    elif m.type in (WSMsgType.CLOSED, WSMsgType.CLOSING, WSMsgType.ERROR): break
        except Exception as e: log("binance ws: %s" % e)
        await asyncio.sleep(back); back = min(30, back * 2)


# ---------- HTTP ----------
async def index(req):
    try: html = open(os.path.join(HERE, "index.html"), encoding="utf-8").read()
    except Exception: return web.Response(status=500, text="no page")
    csp = "default-src 'none'; script-src 'self' 'unsafe-inline' https://telegram.org; style-src 'unsafe-inline'; connect-src 'self' wss://%s; img-src data:; frame-ancestors 'self' https://*.telegram.org https://web.telegram.org" % req.host
    return web.Response(text=html, content_type="text/html", headers={"Cache-Control": "no-store", "Content-Security-Policy": csp, "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer"})


async def ws_handler(req):
    ip = (req.headers.get("X-Forwarded-For") or req.remote or "?").split(",")[0].strip()
    org = req.headers.get("Origin")
    if org and urllib.parse.urlparse(org).netloc != req.host: return web.Response(status=403)
    if len(CL) >= MAXC: return web.Response(status=503)
    if n_fails(ip) >= 8: return web.Response(status=429)
    ws = web.WebSocketResponse(heartbeat=20, max_msg_size=8192); await ws.prepare(req); ok = False
    try:
        m = await asyncio.wait_for(ws.receive(), 8)
        a = json.loads(m.data) if m.type == WSMsgType.TEXT else {}
        ok = check_init(a["init"]) if a.get("init") else check_tok(a.get("tok", ""))
    except Exception: ok = False
    if not ok:
        FAILS.setdefault(ip, []).append(time.time()); log("deny %s" % ip)
        try: await ws.send_json({"t": "deny"})
        except Exception: pass
        await ws.close(); return ws
    CL.add(ws)
    try:
        ctl = (req.transport.get_extra_info("sockname") or ("", 0))[1] == CTL_PORT
        await ws.send_str(json.dumps({"t": "hello", "ctl": ctl, "state": ST["state"], "arch": ST["arch"], "sh": ST.get("sh") or [], "bal": ST.get("bal"), "px": PX, "k": BTCK, "evt": list(EVT)[-80:], "srv": int(time.time() * 1000)}, ensure_ascii=False, default=str))
        async for m in ws:
            if m.type != WSMsgType.TEXT: continue
            try: q = json.loads(m.data)
            except Exception: continue
            if q.get("q") == "candles": await handle_candles(req.app["sess"], ws, q)
            elif q.get("q") == "act" and ctl: await handle_act(req.app["sess"], ws, q, ip)
    finally: CL.discard(ws); LASTQ.pop(id(ws), None)
    return ws


REG_LO, REG_HI, REG_K, REG_FLAT = 40, 350, 2.0, 0.03     # те же параметры, что у источника regr (chan_src.regression_at)
RGC = {}; RG_TTL = {"1m": 30, "1h": 120, "4h": 300}


def reg_channel(rows, per):
    """rows: свечи Binance (последняя может быть формирующейся). Канал регрессии по close закрытых свечей: окно 40..350 с максимальным |Пирсона|, границы +-2 сигма (n-2).
    Возвращает {win, r, dir, t0, upper{t1,p1,s}, lower{...}, mid{...}} в формате страницы (цена = p1 + s*(t - t1), t в мс) или None."""
    now = int(time.time() * 1000)
    k = [x for x in rows if int(x[0]) + per <= now][-REG_HI:]; n = len(k)
    if n < REG_LO + 2: return None
    y = [float(x[4]) for x in k]
    Px = [0.0]; Pxx = [0.0]; Py = [0.0]; Pxy = [0.0]; Pyy = [0.0]
    for i, v in enumerate(y): Px.append(Px[-1] + i); Pxx.append(Pxx[-1] + i * i); Py.append(Py[-1] + v); Pxy.append(Pxy[-1] + i * v); Pyy.append(Pyy[-1] + v * v)
    best = None
    for L in range(REG_LO, n + 1):
        a = n - L; sx = Px[n] - Px[a]; sxx = Pxx[n] - Pxx[a]; sy = Py[n] - Py[a]; sxy = Pxy[n] - Pxy[a]; syy = Pyy[n] - Pyy[a]
        vx = sxx - sx * sx / L; vy = syy - sy * sy / L; cv = sxy - sx * sy / L
        if vx <= 0 or vy <= 0: continue
        r = abs(cv) / (vx * vy) ** 0.5
        if best is None or r > best[0]: best = (r, L, vx, vy, cv, sx, sy)
    if not best: return None
    r, L, vx, vy, cv, sx, sy = best
    slope = cv / vx; yk = sy / L + slope * ((n - 1) - sx / L); sd = (max(vy - slope * cv, 0.0) / max(L - 2, 1)) ** 0.5
    trs = [max(float(k[i][2]) - float(k[i][3]), abs(float(k[i][2]) - y[i - 1]), abs(float(k[i][3]) - y[i - 1])) for i in range(max(1, n - 14), n)]
    atr = sum(trs) / len(trs) if trs else 0.0
    d = 1 if slope > REG_FLAT * atr else (-1 if slope < -REG_FLAT * atr else 0)
    t1 = int(k[-1][0]); s = slope / per; line = lambda p: {"t1": t1, "p1": p, "s": s}
    return {"win": L, "r": round(r, 3), "dir": d, "t0": int(k[n - L][0]), "upper": line(yk + REG_K * sd), "lower": line(yk - REG_K * sd), "mid": line(yk)}


async def _reg_one(sess, sym, iv):
    key = (sym, iv); now = time.time(); c = RGC.get(key)
    if c and now - c[0] < RG_TTL[iv]: return c[1]
    try:
        async with sess.get(KL, params={"symbol": sym, "interval": iv, "limit": REG_HI + 2}) as r: rows = await r.json()
        ch = reg_channel(rows, IVS[iv]); RGC[key] = (now, ch); return ch
    except Exception as e:
        log("reg %s %s: %s" % (sym, iv, e)); return c[1] if (c and now - c[0] < 900) else None


async def reg_all(sess, sym):
    """Каналы регрессии 1m, 1h, 4h (кэш 30 с / 2 мин / 5 мин): {iv: канал}; нет данных по таймфрейму - ключа нет."""
    res = await asyncio.gather(*[_reg_one(sess, sym, iv) for iv in RG_TTL])
    return {iv: ch for iv, ch in zip(RG_TTL, res) if ch}


async def handle_candles(sess, ws, q):
    now = time.time(); k = id(ws)
    if now - LASTQ.get(k, 0) < 0.1: return
    LASTQ[k] = now; sym = str(q.get("sym", "")); iv = str(q.get("iv", "5m")); rid = q.get("rid")
    if not re.fullmatch(r"[A-Z0-9]{2,15}USDT", sym) or iv not in IVS: return
    try:
        pr = {"symbol": sym, "interval": iv, "limit": max(50, min(1000, int(q.get("lim") or 120)))}
        if q.get("end"): pr["endTime"] = int(q["end"])
        async with sess.get(KL, params=pr) as r: rows = await r.json()
        c = [[int(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4]), float(x[5])] for x in rows]
    except Exception as e:
        log("candles %s: %s" % (sym, e)); await ws.send_json({"t": "candles", "rid": rid, "err": 1}); return
    ST["extra"][sym] = now + 60
    if c and sym not in PX: PX[sym] = c[-1][4]; DIRTY.add(sym)
    try: ch = CHANS.get(int(q["oid"])) if q.get("oid") is not None else None
    except Exception: ch = None
    rg = None
    if q.get("rg"):
        try: rg = await reg_all(sess, sym)
        except Exception as e: log("reg_all %s: %s" % (sym, e))
    await ws.send_str(json.dumps({"t": "candles", "rid": rid, "sym": sym, "iv": iv, "c": c, "ch": ch, "rg": rg, "srv": int(time.time() * 1000)}))


ACTS = {"close", "stop", "tp", "tp_auto", "auto", "trail", "ord_cancel", "ord_edit", "watch_keep", "watch_order", "watch_cancel"}
ACT_LOCK = asyncio.Lock()


async def handle_act(sess, ws, q, ip):
    """Ручные действия по позициям (только через порт управления). Исполняет движок бота (pos.api_action через acct-api), страница ничего не считает за него."""
    rid = q.get("rid"); a = str(q.get("a", ""))
    async def ack(ok, err=None, **kw): await ws.send_str(json.dumps(dict({"t": "ack", "rid": rid, "ok": ok, "err": err}, **kw), ensure_ascii=False))
    now = time.time()
    if now - LASTQ.get(("act", id(ws)), 0) < 0.7: return await ack(False, "слишком часто")
    LASTQ[("act", id(ws))] = now
    if a not in ACTS: return await ack(False, "неизвестное действие")
    try:
        body = {"action": a, "id": int(q.get("id"))}
        if a in ("stop", "tp"): body["price"] = float(q.get("price"))
        if a == "trail": body["pct"] = float(q.get("pct"))
        if a == "watch_keep": body["on"] = bool(q.get("on"))
        if a == "watch_order": body.update(entry=str(q.get("entry")), setup=str(q.get("setup")), target=str(q.get("target")))
        if a == "ord_edit":
            for k_ in ("price", "stop", "tp"):
                if q.get(k_) is not None:
                    v_ = float(q[k_])
                    if not (0 < v_ < 1e12): raise ValueError(k_)
                    body[k_] = v_
    except Exception: return await ack(False, "неверные параметры")
    async with ACT_LOCK:
        try:
            async with sess.post(SNAP, json=body) as r: res = await r.json()
        except Exception as e:
            res = {"error": "бот не ответил: %s" % type(e).__name__}
        err = res.get("error") if isinstance(res, dict) else None
        try:
            with open(AUDIT, "a", encoding="utf-8") as f: f.write(json.dumps({"t": int(now * 1000), "ip": ip, "act": body, "err": err}, ensure_ascii=False) + "\n")
        except Exception: pass
    log("act %s %s -> %s" % (a, body.get("id"), err or "ok"))
    ST["force"] = True
    await ack(err is None, err)


async def on_start(app):
    app["sess"] = ClientSession(timeout=ClientTimeout(total=15))
    app["tasks"] = [asyncio.ensure_future(f(app)) for f in (state_loop, px_loop, binance_loop)]


async def on_stop(app):
    for t in app["tasks"]: t.cancel()
    await app["sess"].close()


def make_app():
    app = web.Application(); app.on_startup.append(on_start); app.on_cleanup.append(on_stop)
    app.router.add_get("/live", lambda r: web.HTTPFound("/live/")); app.router.add_get("/live/", index); app.router.add_get("/live/ws", ws_handler)
    app.router.add_get("/live/health", lambda r: web.Response(text="ok"))
    return app


async def main():
    runner = web.AppRunner(make_app()); await runner.setup()
    await web.TCPSite(runner, "127.0.0.1", PORT).start(); await web.TCPSite(runner, "127.0.0.1", CTL_PORT).start()
    stop = asyncio.Event(); loop = asyncio.get_running_loop()
    for sg in (signal.SIGTERM, signal.SIGINT): loop.add_signal_handler(sg, stop.set)
    log("live-web: публичный порт %d (только чтение), порт управления %d (туннель)" % (PORT, CTL_PORT))
    await stop.wait(); await runner.cleanup()


if __name__ == "__main__":
    asyncio.run(main())
