import json, os
srcs = ["/opt/trading-bot/live/data/shadow_bal_trades.json", "/opt/trading-bot/live/shadow_bal_trades.json", "/opt/trading-bot/positions_regr/shadow_bal_trades.json"]
out = {}
for p in srcs:
    try: d = json.load(open(p, encoding="utf-8"))
    except Exception: continue
    for k, v in d.items():
        if k not in out or (v.get("t_out") or 0) >= (out[k].get("t_out") or 0): out[k] = v
dst = "/opt/trading-bot/live/data/shadow_bal_trades.json"
tmp = dst + ".tmp"; json.dump(out, open(tmp, "w", encoding="utf-8"), ensure_ascii=False); os.replace(tmp, dst)
print("journal records", len(out))
