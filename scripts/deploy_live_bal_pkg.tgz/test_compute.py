import json, sys
sys.path.insert(0, "/tmp/lb")
import shadow_ledger as s
o = s.compute("/opt/trading-bot/positions_regr")
for l in o["lines"]:
    f = l.get("full") or {}
    print(l["name"], {k: l[k] for k in ("bal", "pnl", "taken", "closed", "wins", "open", "skipped", "slots")}, "open_list", len(l["open_list"]), "FULL", {k: f.get(k) for k in ("need", "pnl", "taken", "wins", "open", "maxc", "skipped")})
